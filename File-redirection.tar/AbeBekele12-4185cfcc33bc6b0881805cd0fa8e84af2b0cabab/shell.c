#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

// print a start up message
void printWelcome()
{
    printf("******************************************\n"); // 42 stars
    printf("*                                        *\n");
    printf("*      ****Welcome to my shell!****      *\n");
    printf("*                                        *\n");
    printf("******************************************\n");
}

void printPrompt()
{
    char buffer[1000];
    getcwd(buffer, 1000);
    printf("%s$ ", buffer);
}

void printHelp()
{
    printf("\n*** SHELL FEATURES ***"
           "\nList of Built-Ins:"
           "\n> exit <optional exit code>"
           "\n> cd <directory>"
           "\n> pwd"
           "\n> help"
           "\n\nYou can press Ctrl-C to terminate this shell.\n");
}

void handleExit(char *arg)
{
    if (arg == NULL)
    {
        printf("Goodbye!\n");
        exit(0);
    }

    char *endptr = NULL;
    long code = strtol(arg, &endptr, 10);

    if (*endptr != '\0')
    {
        fprintf(stderr, "Exit code must be a number. You entered: %s\n", arg);
        return;
    }

    if (code < 0 || code > 255)
    {
        fprintf(stderr, "Exit code must be a number from 0 to 255! You entered: %ld\n", code);
        return;
    }

    printf("Goodbye!\n");
    exit(code);

}

void handleCd(char *arg)
{
    if (arg == NULL)
    {
        int err = chdir(getenv("HOME"));
        if (err == -1)
        {
            fprintf(stderr, "cd failed: No such file or directory\n");
        }
        return;
    }

    int err = chdir(arg);
    if (err == -1)
    {
        fprintf(stderr, "cd failed: No such file or directory\n");
    }

}

int handleBuiltIns(char *cmd, char *arg)
{
    if (strcmp(cmd, "exit") == 0)
    {
        handleExit(arg);
        return 1;
    }
    else if (strcmp(cmd, "help") == 0)
    {
        printHelp();
        return 1;
    }
    else if (strcmp(cmd, "pwd") == 0)
    {
        char buffer[1000];
        getcwd(buffer, 1000);
        printf("%s\n", buffer);
        return 1;
    }
    else if (strcmp(cmd, "cd") == 0)
    {
        handleCd(arg);
        return 1;
    }

    return 0;
}

void call(char *argv[])
{
    if (handleBuiltIns(argv[0], argv[1]))
    {
        return;
    }

    pid_t pid = 0;
    int status;

    pid = fork();

    if (pid == 0) // in child
    {

        int ret = execvp(argv[0], argv);
        if (ret == -1)
        {
            perror("execvp");
            exit(EXIT_FAILURE);
        }
    }
    if (pid > 0) // in parent
    {
        pid = wait(&status);
    }
    if (pid < 0)
    {
        perror("fork");
    }
    return;
}

int main()
{
    char buffer[1000];

    printWelcome();

    while (1)
    {
        printPrompt();

        fgets(buffer, 1000, stdin);
        // Example: buffer = "cat < in > out\n"

        // 0. parse the command to obtain input and output file names
        char *output = strrchr(buffer, '>');
        if (output != NULL) {
            *output = '\0'; // buffer = "cat < in ", output = " out\n"
            output++;
            output  = strtok(output, " \n");  // output = "out"
        }

        char *input  = strrchr(buffer, '<');// buffer = "cat < in "
        if (input != NULL) {
            *input = '\0'; // buffer = "cat \0", input = " in "
            input++;
            input  = strtok(input, " \n");
        }


        char *argv[1000];
        int i = 0;
        argv[i] = strtok(buffer, " \n");
        while(argv[++i] = strtok(NULL, " \n"));


        // 1. Backup stdin and stdout
        int stdin_bak = dup(STDIN_FILENO);
        int stdout_bak = dup(STDOUT_FILENO);
        // 2. Open input/output files if needed
        // 3. Use dup2 to duplicate the file resourses for the opened files and give them file descriptors stdin and stdout
        if (output != NULL){
            int outfd = open(output, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR);
            dup2(outfd, STDOUT_FILENO);
            close(outfd);
        }
        if (input != NULL){
            int infd = open(input, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IWUSR);
            dup2(infd, STDOUT_FILENO);
            close(infd);
        }
        
        // 4. Close the file descriptors for the opened files.
        // 5. Execute command as usual
        call(argv);

        // 6. Restore stdin and stdout
        dup2(stdout_bak, STDOUT_FILENO);
        dup2(stdin_bak, STDIN_FILENO);
    }

    return 0;
}