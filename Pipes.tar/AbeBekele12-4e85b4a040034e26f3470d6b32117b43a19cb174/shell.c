#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>

// print a start up message
void printWelcome()
{
    printf("******************************************\n"); // 42 stars
    printf("*                                        *\n");
    printf("*      ****Welcome to my shell!****      *\n");
    printf("*                                        *\n");
    printf("******************************************\n");
}

void printPrompt()
{
    char buffer[1000];
    getcwd(buffer, 1000);
    printf("%s$ ", buffer);
}

void printHelp()
{
    printf("\n*** SHELL FEATURES ***"
           "\nList of Built-Ins:"
           "\n> exit <optional exit code>"
           "\n> cd <directory>"
           "\n> pwd"
           "\n> help"
           "\n\nYou can press Ctrl-C to terminate this shell.\n");
}

void handleExit(char *arg)
{
    if (arg == NULL)
    {
        printf("Goodbye!\n");
        exit(0);
    }

    char *endptr = NULL;
    long code = strtol(arg, &endptr, 10);

    if (*endptr != '\0')
    {
        fprintf(stderr, "Exit code must be a number. You entered: %s\n", arg);
        return;
    }

    if (code < 0 || code > 255)
    {
        fprintf(stderr, "Exit code must be a number from 0 to 255! You entered: %ld\n", code);
        return;
    }

    printf("Goodbye!\n");
    exit(code);

}

void handleCd(char *arg)
{
    if (arg == NULL)
    {
        int err = chdir(getenv("HOME"));
        if (err == -1)
        {
            fprintf(stderr, "cd failed: No such file or directory\n");
        }
        return;
    }

    int err = chdir(arg);
    if (err == -1)
    {
        fprintf(stderr, "cd failed: No such file or directory\n");
    }

}

int handleBuiltIns(char *cmd, char *arg)
{
    if (strcmp(cmd, "exit") == 0)
    {
        handleExit(arg);
        return 1;
    }
    else if (strcmp(cmd, "help") == 0)
    {
        printHelp();
        return 1;
    }
    else if (strcmp(cmd, "pwd") == 0)
    {
        char buffer[1000];
        getcwd(buffer, 1000);
        printf("%s\n", buffer);
        return 1;
    }
    else if (strcmp(cmd, "cd") == 0)
    {
        handleCd(arg);
        return 1;
    }

    return 0;
}

void call(char *argv[])  // { "echo", "hello", NULL}
{
    if (handleBuiltIns(argv[0], argv[1]))
    {
        return;
    }

    pid_t pid = 0;
    int status;

    pid = fork();

    if (pid == 0) // in child
    {
        int ret = execvp(argv[0], argv);
        if (ret == -1)
        {
            perror("execvp");
            exit(EXIT_FAILURE);
        }
    }
    if (pid > 0) // in parent
    {
        pid = wait(&status);
    }
    if (pid < 0)
    {
        perror("fork");
    }
    return;
}


int main()
{
    char buffer[1000];

    printWelcome();
    
    int stdin_bak  = dup(STDIN_FILENO);
    int stdout_bak = dup(STDOUT_FILENO);
    
    int pipefd[2];
    
    while (1)
    {
        printPrompt();

        fgets(buffer, 1000, stdin);
        
        char *cmds[1000];
        int i = 0;
        cmds[i] = strtok(buffer, "|");
        while(cmds[++i] = strtok (NULL, "|"));
        
         for (int q = 0; cmds[q] != NULL; q++) {
        //     printf("At %d: %s\n",q, cmds[q]);
            
            char *argv[1000];
            int j = 0;
            argv [j] = strtok(cmds[q], " \n");
            while(argv[++j] = strtok(NULL, " \n"));
            
            if (cmds[q+1] == NULL)
            {
                dup2(stdout_bak, STDOUT_FILENO);
                call(argv);
                dup2(stdin_bak, STDIN_FILENO);
                
            }
            else 
            {
                if (pipe(pipefd) < 0)  {
                    perror("pipe");
                    continue;
                }
               dup2(pipefd[1], STDOUT_FILENO);
               call(argv);
               dup2(pipefd[0], STDIN_FILENO);
               
               close(pipefd[0]);
               close(pipefd[1]);
            }
         }    
    
       
    }
     close(stdin_bak);
     close(stdout_bak);
    
    return 0;
}