#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>


void printwelcome()
{
    printf ("******************************************\n");
    printf ("*                                        *\n");
    printf ("*      ****Welcome to my shell!****      *\n");
    printf ("*                                        *\n");
    printf ("******************************************\n");
}

void printPrompt()
{
    char buffer[1000];
    getcwd(buffer, 1000);
    printf("%s$ ", buffer);
}
void printHelp()
{
    printf("\n*** SHELL FEATURES ***"
           "\nList of Built-Ins:"
           "\n> exit <optional exit code>"
           "\n> cd <directory>"
           "\n> pwd"
           "\n> help"
           "\n\nYou can press Ctrl-C to terminate this shell.\n");
}

int main ()
{
    char buffer[1000];
    
    printwelcome();
    
    while (1)
    {
       printPrompt();
           
       fgets (buffer, 1000, stdin);
       
           
       char *cmd = strtok(buffer, " \n");
       char *arg = strtok(NULL, " \n");
          
        if (strcmp(cmd, "exit") == 0)
        {
            if (arg == NULL)
            {
                printf("Goodbye!\n");  // "Goodbye!\n"
                exit(0);
            }
            else
            {
                char *endptr = NULL;
                long code = strtol(arg, &endptr, 10);
                
                if (*endptr != '\0')
                {
                    fprintf(stderr, "Exit code must be a number. You entered: %s\n", arg);
                }
                else 
                {
                    if (code < 0 || code > 255)
                    {
                        fprintf ( stderr, "Exit code must be a number from 0 to 255! You entered: %ld\n", code);
                    }
                    else
                    {
                        printf ("GoodBye! \n");
                        exit (code);
                        
                    }
                }
            }    
        }
    
        else if (strcmp(cmd, "help") == 0)
        {
            printHelp();
        }
         else if (strcmp(cmd, "pwd") == 0)
        {
            char buffer[1000];
            getcwd(buffer, 1000);
            printf("%s\n", buffer);
        }
        else if (strcmp(cmd, "cd") == 0)
        {
            if (arg == NULL)
            {
               int err = chdir(getenv("HOME"));
               if (err == -1)
                {
                    fprintf ( stderr, "cd failed: No such file or directory\n");
                }
            }
            else
            {
                int err = chdir (arg);
                if (err == -1)
                {
                    fprintf ( stderr, "cd failed: No such file or directory\n");
                }
            }
        }
        else
        {
            fprintf(stderr, "Command, %s, not recognized!\n", cmd);
        }
    }    
}